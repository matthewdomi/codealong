import React from 'react';

function NavItem({ menu }) {
    return (
    <li>{menu}</li>
    )  
  } 
 
  export default NavItem;