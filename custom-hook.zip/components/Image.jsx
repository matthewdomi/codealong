import PIANO from "../assets/img/PIANO.jpg";

export const Image = () => {
    return <img src={PIANO}alt=" " />;
};